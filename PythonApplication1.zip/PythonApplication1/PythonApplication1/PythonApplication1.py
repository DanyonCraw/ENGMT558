import webbrowser
import cv2
import numpy as np
import serial
import time

url = "http://192.168.1.252:81/stream"
webbrowser.open_new(url)
cap = cv2.VideoCapture(url)
arduino = serial.Serial(port="COM4", baudrate=115200, timeout=1)

while True:
    ret, frame = cap.read()
    if not ret:
        print("Failed to grab frame")
        break

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)


    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([179, 255, 255])

    lower_blue = np.array([100, 150, 0])
    upper_blue = np.array([140, 255, 255])

    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([30, 255, 255])

    lower_green = np.array([40, 40, 40])
    upper_green = np.array([70, 255, 255])


    mask_red1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask_red2 = cv2.inRange(hsv, lower_red2, upper_red2)
    mask_red = mask_red1 + mask_red2

    mask_blue = cv2.inRange(hsv, lower_blue, upper_blue)

    mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)

    mask_green = cv2.inRange(hsv, lower_green, upper_green)
   



    red_count = cv2.countNonZero(mask_red)
    blue_count = cv2.countNonZero(mask_blue)
    yellow_count = cv2.countNonZero(mask_yellow)
    green_count = cv2.countNonZero(mask_green)

    my_colours = [red_count, blue_count, yellow_count, green_count]
    
    largest_number = max(my_colours)
    position = my_colours.index(largest_number)
    
    if position == 0:
        dominant_colour ="r"
    elif position == 1:
        dominant_colour  = "b"
    elif position == 2:
        dominant_colour  = "y"
    elif position == 3:
        dominant_colour  = "g"
    else:
        print("colour not detected")
    
    if dominant_colour:
        print(dominant_colour)
        arduino.write(dominant_colour.encode())

    cv2.imshow("Test Stream", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
